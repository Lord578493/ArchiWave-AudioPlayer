﻿namespace ArchiWave
{
    /// Единственное место где определены FFT-константы.
    /// AudioEngine.SampleAggregator и SpectrumRenderer оба ссылаются сюда.
    internal static class AudioConstants
    {
        /// Размер FFT-окна. Степень двойки.
        public const int FftLength = 2048;

        /// log2(FftLength) — требуется для NAudio.FastFourierTransform.FFT().
        public const int FftM = 11;
    }
}