﻿using System;
using NAudio.Dsp;
using NAudio.Wave;

namespace ArchiWave
{
    /// Инкапсулирует воспроизведение MP3 через NAudio и захват FFT-данных.
    /// Событие Stopped срабатывает только при естественном конце трека,
    /// но НЕ при явном вызове Stop() или Load() — это принципиально важно
    /// для корректной логики авто-перехода в MainWindow.
    internal sealed class AudioEngine : IDisposable
    {
        private WaveOutEvent _waveOut;
        private Mp3FileReader _reader;
        private SampleAggregator _aggregator;
        private bool _disposed;

        // ── Публичное API ─────────────────────────────────────────────

        /// Срабатывает когда трек заканчивается естественным образом.
        public event EventHandler<StoppedEventArgs> Stopped;

        public float Volume
        {
            get => _waveOut?.Volume ?? 0f;
            set { if (_waveOut != null) _waveOut.Volume = Clamp01(value); }
        }

        public TimeSpan CurrentTime
        {
            get { try { return _reader?.CurrentTime ?? TimeSpan.Zero; } catch { return TimeSpan.Zero; } }
            set { try { if (_reader != null) _reader.CurrentTime = value; } catch { } }
        }

        public TimeSpan TotalTime
        {
            get { try { return _reader?.TotalTime ?? TimeSpan.Zero; } catch { return TimeSpan.Zero; } }
        }

        public int SampleRate => _reader?.WaveFormat?.SampleRate ?? 44100;
        public bool IsLoaded => _waveOut != null;

        /// Загружает MP3 и немедленно начинает воспроизведение.
        /// Предыдущий трек останавливается молча (без события Stopped).
        public void Load(string path, float volume)
        {
            // Сначала отписываемся — Stop() не должен стрелять событие
            DetachHandler();
            DisposeCore();

            _reader = new Mp3FileReader(path);
            _aggregator = new SampleAggregator(_reader.ToSampleProvider());
            _waveOut = new WaveOutEvent();
            _waveOut.Init(_aggregator);
            _waveOut.Volume = Clamp01(volume);
            _waveOut.PlaybackStopped += OnNAudioStopped;
            _waveOut.Play();
        }

        public void Pause() => _waveOut?.Pause();
        public void Resume() => _waveOut?.Play();

        /// Останавливает воспроизведение без события Stopped.
        public void Stop()
        {
            DetachHandler();
            DisposeCore();
        }

        /// Копирует актуальные FFT-амплитуды в dest.
        public void GetFftData(float[] dest) => _aggregator?.GetFftData(dest);

        // ── Приватные методы ──────────────────────────────────────────

        private void DetachHandler()
        {
            if (_waveOut != null)
                _waveOut.PlaybackStopped -= OnNAudioStopped;
        }

        private void OnNAudioStopped(object sender, StoppedEventArgs e)
            => Stopped?.Invoke(this, e);

        private void DisposeCore()
        {
            // Обнуляем поля ДО Dispose, чтобы другие потоки не получили disposed-объект
            var wo = _waveOut; _waveOut = null;
            var ag = _aggregator; _aggregator = null;
            var rd = _reader; _reader = null;

            wo?.Dispose();
            rd?.Dispose();
            // ag — управляется через wo/rd, отдельного Dispose не требует
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            DetachHandler();
            DisposeCore();
        }

        private static float Clamp01(float v) => v < 0f ? 0f : v > 1f ? 1f : v;

        // ════════════════════════════════════════
        //  SampleAggregator — внутренний класс
        //  Прозрачно захватывает аудио-семплы
        //  из потока NAudio и вычисляет FFT.
        // ════════════════════════════════════════
        private sealed class SampleAggregator : ISampleProvider
        {
            private readonly ISampleProvider _source;

            private readonly float[] _buf = new float[AudioConstants.FftLength];
            private int _pos;
            private readonly Complex[] _work = new Complex[AudioConstants.FftLength];
            private readonly float[] _result = new float[AudioConstants.FftLength / 2];
            private readonly object _lock = new object();

            public WaveFormat WaveFormat => _source.WaveFormat;

            public SampleAggregator(ISampleProvider source) => _source = source;

            public void GetFftData(float[] dest)
            {
                lock (_lock)
                    Array.Copy(_result, dest, Math.Min(dest.Length, _result.Length));
            }

            public int Read(float[] buffer, int offset, int count)
            {
                int read = _source.Read(buffer, offset, count);
                int channels = WaveFormat.Channels;

                for (int i = 0; i < read; i += channels)
                {
                    float s = 0f;
                    for (int c = 0; c < channels; c++) s += buffer[offset + i + c];
                    _buf[_pos++] = s / channels;

                    if (_pos >= AudioConstants.FftLength)
                    {
                        Compute();
                        _pos = 0;
                    }
                }
                return read;
            }

            private void Compute()
            {
                // Окно Ханна — минимизирует спектральные утечки
                for (int j = 0; j < AudioConstants.FftLength; j++)
                {
                    float w = 0.5f - 0.5f * (float)Math.Cos(
                        2.0 * Math.PI * j / (AudioConstants.FftLength - 1));
                    _work[j].X = _buf[j] * w;
                    _work[j].Y = 0f;
                }

                FastFourierTransform.FFT(true, AudioConstants.FftM, _work);

                lock (_lock)
                {
                    for (int j = 0; j < AudioConstants.FftLength / 2; j++)
                    {
                        float re = _work[j].X, im = _work[j].Y;
                        _result[j] = (float)Math.Sqrt(re * re + im * im);
                    }
                }
            }
        }
    }
}