﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Media.Imaging;

namespace ArchiWave
{
    /// Статический хелпер для Desktop Window Manager (DWM).
    /// Обеспечивает живую миниатюру в панели задач.
    internal static class DwmHelper
    {
        // ── P/Invoke ──────────────────────────────────────────────────
        [DllImport("dwmapi.dll", PreserveSig = false)]
        private static extern void DwmSetWindowAttribute(
            IntPtr hwnd, uint attr, ref int val, uint cbAttr);

        [DllImport("dwmapi.dll", PreserveSig = false)]
        private static extern void DwmInvalidateIconicBitmaps(IntPtr hwnd);

        [DllImport("dwmapi.dll", PreserveSig = false)]
        private static extern void DwmSetIconicThumbnail(
            IntPtr hwnd, IntPtr hbmp, uint flags);

        [DllImport("dwmapi.dll", PreserveSig = false)]
        private static extern void DwmSetIconicLivePreviewBitmap(
            IntPtr hwnd, IntPtr hbmp, IntPtr ppt, uint flags);

        [DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObj);

        // ── Константы ─────────────────────────────────────────────────
        private const uint DWMWA_HAS_ICONIC_BITMAP = 10;
        private const uint DWMWA_FORCE_ICONIC_REPRESENTATION = 7;

        public const int WM_SENDICONICTHUMBNAIL = 0x0323;
        public const int WM_SENDICONICLIVEPREVIEW = 0x0326;

        // ── API ───────────────────────────────────────────────────────

        /// Включает режим iconic bitmap — DWM будет запрашивать кадры через WndProc.
        public static void Enable(IntPtr hwnd)
        {
            try
            {
                int one = 1;
                DwmSetWindowAttribute(hwnd, DWMWA_HAS_ICONIC_BITMAP, ref one, sizeof(int));
                DwmSetWindowAttribute(hwnd, DWMWA_FORCE_ICONIC_REPRESENTATION, ref one, sizeof(int));
            }
            catch { /* DWM может быть недоступен (WinXP/Server Core) */ }
        }

        /// Сигнализирует DWM что миниатюра устарела и нужно запросить новую.
        public static void Invalidate(IntPtr hwnd)
        {
            try { DwmInvalidateIconicBitmaps(hwnd); }
            catch { }
        }

        /// Поставляет масштабированную миниатюру по запросу WM_SENDICONICTHUMBNAIL.
        public static void ProvideThumbnail(
            IntPtr hwnd, int maxW, int maxH,
            SpectrumRenderer renderer, double aspectRatio)
        {
            aspectRatio = Math.Max(0.01, aspectRatio);

            int w, h;
            if ((double)maxW / Math.Max(1, maxH) > aspectRatio)
            { h = maxH; w = Math.Max(1, (int)(h * aspectRatio)); }
            else
            { w = maxW; h = Math.Max(1, (int)(w / aspectRatio)); }

            WithHBitmap(renderer.RenderToBitmap(w, h),
                hbmp => DwmSetIconicThumbnail(hwnd, hbmp, 0));
        }

        /// Поставляет полноразмерный кадр по запросу WM_SENDICONICLIVEPREVIEWBITMAP (Aero Peek).
        public static void ProvideLivePreview(
            IntPtr hwnd, SpectrumRenderer renderer, int w, int h)
        {
            WithHBitmap(renderer.RenderToBitmap(Math.Max(1, w), Math.Max(1, h)),
                hbmp => DwmSetIconicLivePreviewBitmap(hwnd, hbmp, IntPtr.Zero, 0));
        }

        // ── Приватные хелперы ─────────────────────────────────────────

        private static void WithHBitmap(RenderTargetBitmap rtb, Action<IntPtr> use)
        {
            if (rtb is null) return;
            IntPtr hbmp = ToHBitmap(rtb);
            if (hbmp == IntPtr.Zero) return;
            try { use(hbmp); }
            catch { }
            finally { DeleteObject(hbmp); }
        }

        private static IntPtr ToHBitmap(RenderTargetBitmap rtb)
        {
            try
            {
                // ИСПОЛЬЗУЕМ BMP ВМЕСТО PNG для максимальной производительности
                var enc = new BmpBitmapEncoder();
                enc.Frames.Add(BitmapFrame.Create(rtb));

                using (var ms = new MemoryStream())
                {
                    enc.Save(ms);
                    ms.Position = 0;
                    using (var bmp = new System.Drawing.Bitmap(ms))
                        return bmp.GetHbitmap(System.Drawing.Color.Black);
                }
            }
            catch { return IntPtr.Zero; }
        }
    }
}