using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using IOFile  = System.IO.File;
using IOPath  = System.IO.Path;
using TFile   = TagLib.File;

namespace ArchiWave
{
    public partial class MainWindow : Window
    {
        // ── Пути сохранения ───────────────────────────────────────────
        private static readonly string SaveDir =
            IOPath.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ArchiWave");
        private static readonly string PlaylistPath = IOPath.Combine(SaveDir, "playlist.json");

        // ── Аудио ─────────────────────────────────────────────────────
        private readonly AudioEngine _audio = new AudioEngine();

        // ── Плейлист ──────────────────────────────────────────────────
        private readonly List<string> _playlist = new List<string>();

        // FIX: Кеш тайтлов — устраняет двойное чтение TagLib при Drop.
        private readonly Dictionary<string, string> _titleCache = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        private int _currentIndex = -1;
        private bool _isPlaylistOpen;
        private bool _suppressSel;

        // ── Состояние плеера ──────────────────────────────────────────
        private enum PlayState { Stopped, Playing, Paused }
        private PlayState _state = PlayState.Stopped;
        private bool _isRepeat;
        private bool _isSeeking;   // защита: не двигать прогресс во время drag

        // ── UI-анимация (пульсация цвета) ─────────────────────────────
        private readonly SolidColorBrush _borderBrush = new SolidColorBrush(Color.FromRgb(0, 191, 255));
        private readonly SolidColorBrush _repeatBrush = new SolidColorBrush(Color.FromRgb(0, 255, 159));
        private double _borderPhase, _repeatPhase;

        // ── Окно ──────────────────────────────────────────────────────
        private bool _isMaximized;
        private double _restoreLeft, _restoreTop, _restoreW, _restoreH;
        private IntPtr _hwnd;

        // ── DWM ───────────────────────────────────────────────────────
        private int _dwmTick;
        private const int DWM_EVERY = 2;

        // ── WM_NCHITTEST — именованные константы (замена magic numbers) ──
        private const int HTLEFT        = 10;
        private const int HTRIGHT       = 11;
        private const int HTTOP         = 12;
        private const int HTTOPLEFT     = 13;
        private const int HTTOPRIGHT    = 14;
        private const int HTBOTTOM      = 15;
        private const int HTBOTTOMLEFT  = 16;
        private const int HTBOTTOMRIGHT = 17;
        private const int WM_NCHITTEST  = 0x0084;

        private readonly DispatcherTimer _uiTimer;

        // ════════════════════════════════════════
        //  КОНСТРУКТОР
        // ════════════════════════════════════════
        public MainWindow()
        {
            InitializeComponent();
            MainBorder.BorderBrush = _borderBrush;

            _audio.Stopped += OnAudioStopped;

            Loaded += (_, __) =>
            {
                _hwnd = new WindowInteropHelper(this).Handle;
                HwndSource.FromHwnd(_hwnd)?.AddHook(WndProc);
                DwmHelper.Enable(_hwnd);
                LoadPlaylist();
                Dispatcher.BeginInvoke(new Action(ShowScanDialog), DispatcherPriority.Loaded);
            };

            Closed += (_, __) =>
            {
                _uiTimer?.Stop();
                SavePlaylist();
                _audio?.Dispose();
            };

            _uiTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(16) };
            _uiTimer.Tick += OnUiTick;
            _uiTimer.Start();
        }

        // ════════════════════════════════════════
        //  ГЛАВНЫЙ ТИК (~60fps)
        // ════════════════════════════════════════
        private void OnUiTick(object sender, EventArgs e)
        {
            bool playing = _state == PlayState.Playing;

            if (playing)
                SpectrumCanvas.FetchFftData(_audio.GetFftData);

            if (WindowState == WindowState.Minimized)
            {
                SpectrumCanvas.UpdateHeights(playing);
            }
            else
            {
                SpectrumCanvas.Render(playing);
                UpdateProgressBar();
                PulseBorder();
                PulseRepeatButton();
            }

            if (playing || _state == PlayState.Paused)
                ThrottledDwmInvalidate();
        }

        private void UpdateProgressBar()
        {
            if (_isSeeking || _state != PlayState.Playing || !_audio.IsLoaded) return;
            try
            {
                double total = _audio.TotalTime.TotalSeconds;
                if (total <= 0) return;
                TrackProgress.Value = _audio.CurrentTime.TotalSeconds / total * 100.0;
                TimeLabel.Text = $"{_audio.CurrentTime:mm\\:ss} / {_audio.TotalTime:mm\\:ss}";
            }
            catch { }
        }

        private void PulseBorder()
        {
            _borderPhase += _state == PlayState.Playing ? 0.06 : 0.02;
            double p = (Math.Sin(_borderPhase) + 1.0) / 2.0;
            _borderBrush.Color = Color.FromRgb(0, (byte)(175 + p * 60), 255);
        }

        private void PulseRepeatButton()
        {
            if (!_isRepeat) return;
            _repeatPhase += 0.08;
            double p = (Math.Sin(_repeatPhase) + 1.0) / 2.0;
            _repeatBrush.Color = Color.FromRgb(0, (byte)(180 + p * 75), (byte)(100 + p * 50));
            RepeatButton.BorderBrush = _repeatBrush;
        }

        private void ThrottledDwmInvalidate()
        {
            if (++_dwmTick < DWM_EVERY) return;
            _dwmTick = 0;
            DwmHelper.Invalidate(_hwnd);
        }

        // ════════════════════════════════════════
        //  ВОСПРОИЗВЕДЕНИЕ
        // ════════════════════════════════════════
        private void PlayTrack(int index)
        {
            if (index < 0 || index >= _playlist.Count) return;

            if (!IOFile.Exists(_playlist[index]))
            {
                MessageBox.Show($"Файл не найден:\n{_playlist[index]}",
                    "ArchiWave", MessageBoxButton.OK, MessageBoxImage.Warning);
                ResetToStopped();
                return;
            }

            try
            {
                _audio.Load(_playlist[index], (float)(VolumeSlider.Value / 100.0));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка воспроизведения:\n{ex.Message}",
                    "ArchiWave", MessageBoxButton.OK, MessageBoxImage.Error);
                ResetToStopped();
                return;
            }

            _currentIndex = index;
            TrackLabel.Text = GetTitle(_playlist[index]);
            SpectrumCanvas.SetAudioParameters(_audio.SampleRate);

            _suppressSel = true;
            PlaylistView.SelectedIndex = index;
            // FIX: Прокручиваем список к текущему треку
            PlaylistView.ScrollIntoView(PlaylistView.SelectedItem);
            _suppressSel = false;

            _state = PlayState.Playing;
            RefreshPlayButton();
            RefreshNavButtons();
        }

        private void OnAudioStopped(object sender, NAudio.Wave.StoppedEventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                if (_isRepeat && _state == PlayState.Playing)
                {
                    PlayTrack(_currentIndex);
                    return;
                }
                if (_state == PlayState.Playing && _currentIndex < _playlist.Count - 1)
                {
                    PlayTrack(_currentIndex + 1);
                    return;
                }
                ResetToStopped();
            });
        }

        private void ResetToStopped()
        {
            _audio?.Stop();
            _state = PlayState.Stopped;
            TrackProgress.Value = 0;
            TimeLabel.Text = "0:00 / 0:00";
            SpectrumCanvas.ResetBars();
            RefreshPlayButton();
            RefreshNavButtons();
        }

        // ════════════════════════════════════════
        //  КНОПКИ УПРАВЛЕНИЯ
        // ════════════════════════════════════════
        private void PlayPauseButton_Click(object sender, RoutedEventArgs e)
        {
            switch (_state)
            {
                case PlayState.Playing:
                    _audio.Pause();
                    _state = PlayState.Paused;
                    break;

                case PlayState.Paused:
                    _audio.Resume();
                    _state = PlayState.Playing;
                    break;

                case PlayState.Stopped when _playlist.Count > 0:
                    PlayTrack(_currentIndex >= 0 ? _currentIndex : 0);
                    return;
            }
            RefreshPlayButton();
        }

        // FIX: Новые кнопки — Предыдущий трек
        private void PrevButton_Click(object sender, RoutedEventArgs e)
        {
            if (_playlist.Count == 0) return;
            int idx = _currentIndex > 0 ? _currentIndex - 1 : _playlist.Count - 1;
            PlayTrack(idx);
        }

        // FIX: Новые кнопки — Следующий трек
        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (_playlist.Count == 0) return;
            int idx = _currentIndex < _playlist.Count - 1 ? _currentIndex + 1 : 0;
            PlayTrack(idx);
        }

        private void RefreshPlayButton()
        {
            string styleKey = _state == PlayState.Paused ? "NeonPauseActiveButton" : "NeonPlayButton";
            PlayPauseButton.Style = (Style)FindResource(styleKey);

            if (_state == PlayState.Playing)       PlayPauseButton.Content = "⏸  ПАУЗА";
            else if (_state == PlayState.Paused)   PlayPauseButton.Content = "▶  ПРОДОЛЖИТЬ";
            else                                   PlayPauseButton.Content = "▶  ИГРАТЬ";
        }

        // FIX: Обновление доступности кнопок Prev/Next
        private void RefreshNavButtons()
        {
            bool has = _playlist.Count > 0;
            PrevButton.IsEnabled = has;
            NextButton.IsEnabled = has;
        }

        private void RepeatButton_Click(object sender, RoutedEventArgs e)
        {
            _isRepeat = !_isRepeat;

            var tf  = new ScaleTransform(1, 1, 54, 17);
            var axX = new DoubleAnimation(1.0, 1.12, TimeSpan.FromMilliseconds(80)) { AutoReverse = true };
            var axY = new DoubleAnimation(1.0, 1.12, TimeSpan.FromMilliseconds(80)) { AutoReverse = true };
            RepeatButton.RenderTransform = tf;
            tf.BeginAnimation(ScaleTransform.ScaleXProperty, axX);
            tf.BeginAnimation(ScaleTransform.ScaleYProperty, axY);

            if (_isRepeat)
            {
                RepeatButton.Content = "↺  ПОВТОР ВКЛ";
                RepeatButton.Style   = (Style)FindResource("NeonRepeatActiveButton");
            }
            else
            {
                RepeatButton.Content      = "↺  ПОВТОР";
                RepeatButton.Style        = (Style)FindResource("NeonPlayButton");
                RepeatButton.BorderBrush  = null;
            }
        }

        // ── Прогресс-бар: клик ────────────────────────────────────────
        private void ProgressBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!_audio.IsLoaded) return;
            _isSeeking = true;
            SeekToPosition(e.GetPosition(ProgressHitArea).X);
        }

        // FIX: Прогресс-бар: drag (перетаскивание, а не только клик)
        private void ProgressBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_isSeeking || !_audio.IsLoaded) return;
            SeekToPosition(e.GetPosition(ProgressHitArea).X);
        }

        private void ProgressBar_MouseUp(object sender, MouseButtonEventArgs e)
        {
            _isSeeking = false;
        }

        private void SeekToPosition(double posX)
        {
            double width = ProgressHitArea.ActualWidth;
            if (width <= 0) return;
            double ratio = Math.Max(0, Math.Min(1, posX / width));
            try
            {
                _audio.CurrentTime    = TimeSpan.FromSeconds(ratio * _audio.TotalTime.TotalSeconds);
                TrackProgress.Value   = ratio * 100.0;
                TimeLabel.Text = $"{_audio.CurrentTime:mm\\:ss} / {_audio.TotalTime:mm\\:ss}";
            }
            catch { }
        }

        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_audio      != null) _audio.Volume    = (float)(e.NewValue / 100.0);
            if (VolumeLabel != null) VolumeLabel.Text = $"{(int)e.NewValue}%";
        }

        // ════════════════════════════════════════
        //  ПЛЕЙЛИСТ
        // ════════════════════════════════════════
        private void Window_Drop(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;
            if (!(e.Data.GetData(DataFormats.FileDrop) is string[] files)) return;

            bool wasEmpty = _playlist.Count == 0;
            int added = 0;
            foreach (var file in files)
            {
                if (!file.EndsWith(".mp3", StringComparison.OrdinalIgnoreCase)) continue;

                // FIX: Защита от дублей
                if (_playlist.Contains(file)) continue;

                _playlist.Add(file);
                PlaylistView.Items.Add(GetTitle(file));
                added++;
            }

            if (added > 0) SavePlaylist();
            if (wasEmpty && _playlist.Count > 0) PlayTrack(0);
            RefreshNavButtons();
        }

        private void PlaylistView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_suppressSel) return;
            int idx = PlaylistView.SelectedIndex;
            if (idx >= 0 && idx != _currentIndex) PlayTrack(idx);
        }

        private void TogglePlaylist_Click(object sender, RoutedEventArgs e) => SetPlaylistOpen(!_isPlaylistOpen);

        private void SetPlaylistOpen(bool open)
        {
            if (_isPlaylistOpen == open) return;
            ((Storyboard)FindResource(open ? "OpenPlaylist" : "ClosePlaylist")).Begin();
            PlaylistTrigger.Content = open ? "✕" : "☰";
            _isPlaylistOpen = open;
        }

        // ════════════════════════════════════════
        //  СОХРАНЕНИЕ / ЗАГРУЗКА ПЛЕЙЛИСТА (JSON)
        // ════════════════════════════════════════

        /// FIX: Сохраняем плейлист в %AppData%\ArchiWave\playlist.json
        private void SavePlaylist()
        {
            try
            {
                Directory.CreateDirectory(SaveDir);
                // Простой JSON-массив строк без внешних зависимостей
                var sb = new System.Text.StringBuilder();
                sb.AppendLine("[");
                for (int i = 0; i < _playlist.Count; i++)
                {
                    string escaped = _playlist[i].Replace("\\", "\\\\").Replace("\"", "\\\"");
                    sb.Append($"  \"{escaped}\"");
                    if (i < _playlist.Count - 1) sb.Append(",");
                    sb.AppendLine();
                }
                sb.AppendLine("]");
                IOFile.WriteAllText(PlaylistPath, sb.ToString(), System.Text.Encoding.UTF8);
            }
            catch { /* Не критично — молча игнорируем */ }
        }

        /// FIX: Загружаем плейлист при старте — только файлы которые ещё существуют
        private void LoadPlaylist()
        {
            if (!IOFile.Exists(PlaylistPath)) return;
            try
            {
                string json = IOFile.ReadAllText(PlaylistPath, System.Text.Encoding.UTF8);
                // Минимальный парсер JSON-массива строк (без System.Text.Json / Newtonsoft)
                var paths = ParseJsonStringArray(json);
                foreach (var path in paths)
                {
                    if (!IOFile.Exists(path)) continue;          // файл удалён — пропускаем
                    if (_playlist.Contains(path)) continue;       // дубль — пропускаем
                    _playlist.Add(path);
                    PlaylistView.Items.Add(GetTitle(path));
                }
                RefreshNavButtons();

                if (_playlist.Count > 0)
                    SetPlaylistOpen(true);
            }
            catch { /* Повреждённый файл — стартуем с пустым плейлистом */ }
        }

        private static List<string> ParseJsonStringArray(string json)
        {
            var result = new List<string>();
            // Ищем строки в кавычках, учитываем escape-последовательности
            int i = 0;
            while (i < json.Length)
            {
                if (json[i] == '"')
                {
                    i++;
                    var sb = new System.Text.StringBuilder();
                    while (i < json.Length && json[i] != '"')
                    {
                        if (json[i] == '\\' && i + 1 < json.Length)
                        {
                            i++;
                            switch (json[i])
                            {
                                case '"':  sb.Append('"');  break;
                                case '\\': sb.Append('\\'); break;
                                default:   sb.Append(json[i]); break;
                            }
                        }
                        else sb.Append(json[i]);
                        i++;
                    }
                    result.Add(sb.ToString());
                }
                i++;
            }
            return result;
        }

        // ════════════════════════════════════════
        //  ДИАЛОГ СКАНИРОВАНИЯ
        // ════════════════════════════════════════
        private void ShowScanDialog()
        {
            string folder = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);
            if (!Directory.Exists(folder)) return;

            var dlg = new ScanDialog(folder) { Owner = this };
            if (dlg.ShowDialog() != true) return;

            int added = 0;
            foreach (var file in dlg.FoundFiles)
            {
                if (_playlist.Contains(file)) continue;  // FIX: защита от дублей
                _playlist.Add(file);
                PlaylistView.Items.Add(GetTitle(file));
                added++;
            }

            if (added > 0)
            {
                SavePlaylist();
                RefreshNavButtons();
                SetPlaylistOpen(true);
            }
        }

        // ════════════════════════════════════════
        //  УПРАВЛЕНИЕ ОКНОМ
        // ════════════════════════════════════════
        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            if (!_isMaximized)
            {
                _restoreLeft = Left; _restoreTop = Top;
                _restoreW = Width;   _restoreH = Height;

                var wa = SystemParameters.WorkArea;
                Left = wa.Left; Top = wa.Top; Width = wa.Width; Height = wa.Height;

                MainBorder.CornerRadius    = new CornerRadius(0);
                MainBorder.BorderThickness = new Thickness(0);
                MaximizeButton.Content     = "❐";
                _isMaximized = true;
            }
            else
            {
                Left = _restoreLeft; Top = _restoreTop;
                Width = _restoreW;   Height = _restoreH;

                MainBorder.CornerRadius    = new CornerRadius(14);
                MainBorder.BorderThickness = new Thickness(1.5);
                MaximizeButton.Content     = "□";
                _isMaximized = false;
            }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.Source is Button || e.Source is ListBoxItem || e.Source is Thumb) return;
            try { DragMove(); } catch { }
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void CloseButton_Click(object sender, RoutedEventArgs e)    => Close();
        private void SettingsButton_Click(object sender, RoutedEventArgs e) => SettingsPanel.Visibility = Visibility.Visible;
        private void SettingsCloseButton_Click(object sender, RoutedEventArgs e) => SettingsPanel.Visibility = Visibility.Collapsed;

        private void TopMostButton_Click(object sender, RoutedEventArgs e)
        {
            Topmost = !Topmost;
            TopMostButton.Content = Topmost ? "ВКЛ" : "ВЫКЛ";
        }

        // ════════════════════════════════════════
        //  WIN32 WNDPROC
        // ════════════════════════════════════════
        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            switch (msg)
            {
                case DwmHelper.WM_SENDICONICTHUMBNAIL:
                {
                    int tw = (int)((lParam.ToInt64() >> 16) & 0xFFFF);
                    int th = (int)(lParam.ToInt64() & 0xFFFF);
                    double ar = ActualWidth > 1 && ActualHeight > 1 ? ActualWidth / ActualHeight : 16.0 / 9.0;
                    DwmHelper.ProvideThumbnail(hwnd, tw, th, SpectrumCanvas, ar);
                    handled = true;
                    return IntPtr.Zero;
                }
                case DwmHelper.WM_SENDICONICLIVEPREVIEW:
                    DwmHelper.ProvideLivePreview(hwnd, SpectrumCanvas, (int)ActualWidth, (int)ActualHeight);
                    handled = true;
                    return IntPtr.Zero;

                case WM_NCHITTEST:
                    return HitTest(lParam, ref handled);
            }
            return IntPtr.Zero;
        }

        private IntPtr HitTest(IntPtr lParam, ref bool handled)
        {
            int x = (int)(short)(lParam.ToInt64() & 0xFFFF);
            int y = (int)(short)((lParam.ToInt64() >> 16) & 0xFFFF);
            Point p = PointFromScreen(new Point(x, y));

            const int E = 15;
            bool inBtnRow = p.Y > ActualHeight / 2 - 40 && p.Y < ActualHeight / 2 + 40;
            int lEdge = inBtnRow ? 3 : E;

            // FIX: Именованные константы вместо magic numbers
            if (p.X < E  && p.Y < E)                         { handled = true; return new IntPtr(HTTOPLEFT);     }
            if (p.X > ActualWidth - E && p.Y < E)            { handled = true; return new IntPtr(HTTOPRIGHT);    }
            if (p.X < E  && p.Y > ActualHeight - E)          { handled = true; return new IntPtr(HTBOTTOMLEFT);  }
            if (p.X > ActualWidth - E && p.Y > ActualHeight - E) { handled = true; return new IntPtr(HTBOTTOMRIGHT); }
            if (p.Y < E)                                      { handled = true; return new IntPtr(HTTOP);         }
            if (p.Y > ActualHeight - E)                       { handled = true; return new IntPtr(HTBOTTOM);      }
            if (p.X < lEdge)                                  { handled = true; return new IntPtr(HTLEFT);        }
            if (p.X > ActualWidth - E)                        { handled = true; return new IntPtr(HTRIGHT);       }

            return IntPtr.Zero;
        }

        // ════════════════════════════════════════
        //  ВСПОМОГАТЕЛЬНЫЕ
        // ════════════════════════════════════════

        /// FIX: Кеш тайтлов — TagLib открывает файл только один раз за путь.
        private string GetTitle(string path)
        {
            if (_titleCache.TryGetValue(path, out string cached)) return cached;
            string title = ReadTrackTitle(path);
            _titleCache[path] = title;
            return title;
        }

        private static string ReadTrackTitle(string path)
        {
            try
            {
                using (var f = TFile.Create(path))
                {
                    string artist = f.Tag.FirstPerformer?.Trim();
                    string title  = f.Tag.Title?.Trim();
                    if (!string.IsNullOrEmpty(title) && !string.IsNullOrEmpty(artist))
                        return $"{artist}  —  {title}";
                    if (!string.IsNullOrEmpty(title)) return title;
                }
            }
            catch { }
            return IOPath.GetFileNameWithoutExtension(path);
        }
    }
}
