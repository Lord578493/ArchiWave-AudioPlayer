using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using IOPath = System.IO.Path;

namespace ArchiWave
{
    public partial class ScanDialog : Window
    {
        public IReadOnlyList<string> FoundFiles => _foundFiles;

        private readonly List<string> _foundFiles = new List<string>();
        private readonly string _musicFolder;
        private readonly SolidColorBrush _borderBrush = new SolidColorBrush(Color.FromRgb(0, 191, 255));

        private string[] _allFiles = Array.Empty<string>();
        private int _scanIndex;
        private DispatcherTimer _scanTimer;
        private DispatcherTimer _pulseTimer;
        private double _pulsePhase;

        // FIX: Пакетный режим — обрабатываем N файлов за один тик.
        // При 500 файлах и BATCH_SIZE=10 сканирование займёт ~2с вместо ~20с.
        private const int BATCH_SIZE = 10;

        public ScanDialog(string musicFolder)
        {
            InitializeComponent();
            _musicFolder = musicFolder;

            MusicPathLabel.Text = musicFolder.Length > 45
                ? "..." + musicFolder.Substring(musicFolder.Length - 42)
                : musicFolder;

            RootBorder.BorderBrush = _borderBrush;

            _pulseTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(30) };
            _pulseTimer.Tick += (_, __) =>
            {
                _pulsePhase += 0.06;
                double p = (Math.Sin(_pulsePhase) + 1.0) / 2.0;
                _borderBrush.Color = Color.FromRgb(0, (byte)(175 + p * 60), 255);
            };
            _pulseTimer.Start();
        }

        // ── Перетаскивание окна ───────────────────────────────────────
        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.Source is Button) return;
            try { DragMove(); } catch { }
        }

        // ── Кнопки ───────────────────────────────────────────────────
        private void CloseBtn_Click(object sender, RoutedEventArgs e) => Finish(false);
        private void NoBtn_Click(object sender, RoutedEventArgs e)    => Finish(false);
        private void AddBtn_Click(object sender, RoutedEventArgs e)   => Finish(true);

        private void Finish(bool accepted)
        {
            StopTimers();
            DialogResult = accepted;
            Close();
        }

        // ── Запуск сканирования ───────────────────────────────────────
        private async void YesBtn_Click(object sender, RoutedEventArgs e)
        {
            QuestionPanel.Visibility = Visibility.Collapsed;
            ScanPanel.Visibility     = Visibility.Visible;
            ScanStatusLabel.Text     = "Поиск файлов на диске...";

            _allFiles = await Task.Run(() =>
            {
                try
                {
                    return Directory.GetFiles(_musicFolder, "*.mp3", SearchOption.AllDirectories);
                }
                catch { return Array.Empty<string>(); }
            });

            if (_allFiles.Length == 0)
            {
                ScanStatusLabel.Text = "MP3 файлы не найдены.";
                ShowResult("Папка «Музыка» пуста.");
                return;
            }

            ScanStatusLabel.Text = $"Сканирование...  0 / {_allFiles.Length}";

            // FIX: Интервал 40мс, но обрабатываем BATCH_SIZE файлов за тик
            _scanTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(40) };
            _scanTimer.Tick += OnScanTick;
            _scanTimer.Start();
        }

        // ── Тик сканера (пакетный) ────────────────────────────────────
        private void OnScanTick(object sender, EventArgs e)
        {
            if (_scanIndex >= _allFiles.Length)
            {
                _scanTimer.Stop();
                OnScanComplete();
                return;
            }

            // FIX: Обрабатываем пакет файлов за один тик
            int end = Math.Min(_scanIndex + BATCH_SIZE, _allFiles.Length);
            for (int i = _scanIndex; i < end; i++)
            {
                string file = _allFiles[i];
                _foundFiles.Add(file);

                var item = new TextBlock
                {
                    Text       = IOPath.GetFileNameWithoutExtension(file),
                    Foreground = new SolidColorBrush(Color.FromRgb(126, 200, 227)),
                    FontFamily = new FontFamily("Consolas"),
                    FontSize   = 10,
                    Margin     = new Thickness(0, 1, 0, 1),
                    Opacity    = 0
                };
                item.BeginAnimation(OpacityProperty,
                    new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(200)));

                ScanFileList.Children.Add(item);
            }

            _scanIndex = end;
            ScanScroll.ScrollToEnd();
            ScanStatusLabel.Text = $"Сканирование...  {_scanIndex} / {_allFiles.Length}";
            ProgressFill.Width   = ProgressBorder.ActualWidth * ((double)_scanIndex / _allFiles.Length);
        }

        private void OnScanComplete()
        {
            ProgressFill.Width       = ProgressBorder.ActualWidth;
            ScanStatusLabel.Text     = "✓  Сканирование завершено";
            ScanStatusLabel.Foreground = new SolidColorBrush(Color.FromRgb(0, 255, 159));
            ShowResult($"Найдено треков:  {_foundFiles.Count}");

            AddBtn.Visibility = Visibility.Visible;
            AddBtn.BeginAnimation(OpacityProperty,
                new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(400)));
        }

        private void ShowResult(string text)
        {
            ResultLabel.Text       = text;
            ResultLabel.Visibility = Visibility.Visible;
        }

        private void StopTimers()
        {
            _scanTimer?.Stop();
            _pulseTimer?.Stop();
        }

        protected override void OnClosed(EventArgs e)
        {
            StopTimers();
            base.OnClosed(e);
        }
    }
}
