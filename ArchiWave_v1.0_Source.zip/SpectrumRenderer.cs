using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace ArchiWave
{
    /// Визуализатор спектра на базе DrawingVisual.
    /// FIX: Кеш кистей — статический массив заранее вычисленных Frozen-кистей.
    /// Было: new SolidColorBrush() на каждый кадр × N баров = ~2400 аллокаций/сек.
    /// Стало: 0 аллокаций в горячем пути.
    public sealed class SpectrumRenderer : FrameworkElement
    {
        // ── Визуальные настройки ──────────────────────────────────────
        private const double MIN_FREQ       = 20.0;
        private const double MAX_FREQ       = 20000.0;
        private const double BAR_FILL_RATIO = 0.78;
        private const double MIN_BAR_PX     = 4.0;
        private const double MAX_BAR_PX     = 16.0;
        private const double SLOT_PX        = 16.0;
        private const double RISE_COEFF     = 0.55;
        private const double FALL_COEFF     = 0.12;
        private const double PEAK_FALL_PX   = 1.8;
        private const double LOW_EQ_SCALE   = 0.70;
        private const double HIGH_EQ_BOOST  = 1.50;
        private const double BAR_AMPLITUDE  = 2.20;
        private const double BAR_CORNER     = 2.0;
        private const double MIN_BAR_H      = 2.0;
        private const double PEAK_H         = 2.0;
        private const double PEAK_OFFSET    = 3.0;

        // ── Кеш кистей (замена GetBarBrush) ──────────────────────────
        // Размер определяет разрешение градиента — 256 шагов более чем достаточно.
        private const int BRUSH_CACHE_SIZE = 256;
        private static readonly Brush[] _barBrushCache = BuildBarBrushCache(BRUSH_CACHE_SIZE);
        private static Brush[] BuildBarBrushCache(int count)
        {
            var cache = new Brush[count];
            for (int i = 0; i < count; i++)
            {
                double t = (double)i / Math.Max(1, count - 1);
                Color c = t < 0.5
                    ? Color.FromRgb(0, (byte)(255 - 120 * t), (byte)(200 + 55 * t))
                    : Color.FromRgb((byte)(255 * (t - 0.5) * 2), (byte)(150 - 100 * t), 255);
                var b = new SolidColorBrush(c);
                b.Freeze();
                cache[i] = b;
            }
            return cache;
        }

        // ── FFT-параметры ─────────────────────────────────────────────
        private const int FFT_LENGTH = AudioConstants.FftLength;

        private int _sampleRate;
        private float[] _fftData;

        // ── Состояние анимации ────────────────────────────────────────
        private double[] _heights;
        private double[] _peaks;
        private double _lastH = 200.0;
        private int[] _binStart;
        private int[] _binEnd;
        private int _barCount;

        private readonly DrawingVisual _dv = new DrawingVisual();

        private static readonly Brush BgBrush   = MakeBrush(Color.FromRgb(13, 15, 26));
        private static readonly Brush PeakBrush = MakeBrush(Color.FromArgb(200, 255, 255, 255));

        public SpectrumRenderer()
        {
            AddVisualChild(_dv);
            AddLogicalChild(_dv);
            RenderOptions.SetEdgeMode(_dv, EdgeMode.Aliased);
        }

        protected override int VisualChildrenCount => 1;
        protected override Visual GetVisualChild(int index) => _dv;

        // ════════════════════════════════════════
        //  Публичный API
        // ════════════════════════════════════════

        public void SetAudioParameters(int sampleRate)
        {
            _sampleRate = sampleRate;
            _fftData    = new float[FFT_LENGTH / 2];
            RebuildBinMapping();
        }

        public void FetchFftData(Action<float[]> getter)
        {
            if (_fftData != null) getter(_fftData);
        }

        public void UpdateHeights(bool hasData)
        {
            if (_barCount <= 0 || _heights == null) return;
            for (int i = 0; i < _barCount; i++)
                StepBar(i, ComputeTarget(i, _lastH, hasData));
        }

        public void Render(bool hasData)
        {
            double w = ActualWidth;
            double h = ActualHeight;
            bool canDraw = w >= 1 && h >= 1;

            if (canDraw)
            {
                _lastH = h;
                int newCount = Math.Max(8, (int)(w / SLOT_PX));
                if (newCount != _barCount)
                {
                    _barCount = newCount;
                    _heights  = new double[_barCount];
                    _peaks    = new double[_barCount];
                    RebuildBinMapping();
                }
            }

            if (_barCount <= 0) return;

            double ch = canDraw ? h : _lastH;
            for (int i = 0; i < _barCount; i++)
                StepBar(i, ComputeTarget(i, ch, hasData));

            if (canDraw) DrawFrame(w, h);
        }

        public RenderTargetBitmap RenderToBitmap(int width, int height)
        {
            if (_barCount <= 0 || _heights == null || _lastH < 1) return null;

            double scale  = height / _lastH;
            double slotW  = (double)width / _barCount;
            double barW   = Math.Max(MIN_BAR_PX, Math.Min(MAX_BAR_PX, slotW * BAR_FILL_RATIO));
            double barOffX = (slotW - barW) / 2.0;

            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                dc.DrawRectangle(BgBrush, null, new Rect(0, 0, width, height));
                for (int i = 0; i < _barCount; i++)
                {
                    double barH = Math.Max(MIN_BAR_H, _heights[i] * scale);
                    double t    = (double)i / Math.Max(1, _barCount - 1);
                    double x    = i * slotW + barOffX;

                    dc.DrawRoundedRectangle(GetCachedBrush(t), null,
                        new Rect(x, height - barH, barW, barH),
                        BAR_CORNER, BAR_CORNER);

                    double peakY = _peaks[i] * scale;
                    if (peakY > MIN_BAR_H)
                        dc.DrawRectangle(PeakBrush, null,
                            new Rect(x, height - peakY - PEAK_OFFSET, barW, PEAK_H));
                }
            }

            var rtb = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(dv);
            return rtb;
        }

        public void ResetBars()
        {
            if (_heights != null) Array.Clear(_heights, 0, _heights.Length);
            if (_peaks   != null) Array.Clear(_peaks,   0, _peaks.Length);
            using (DrawingContext dc = _dv.RenderOpen()) { /* пустой кадр */ }
        }

        // ════════════════════════════════════════
        //  Приватные методы
        // ════════════════════════════════════════

        /// FIX: Получение кисти из кеша — 0 аллокаций.
        private static Brush GetCachedBrush(double t)
        {
            int idx = (int)(t * (BRUSH_CACHE_SIZE - 1));
            idx = idx < 0 ? 0 : idx >= BRUSH_CACHE_SIZE ? BRUSH_CACHE_SIZE - 1 : idx;
            return _barBrushCache[idx];
        }

        private void StepBar(int i, double target)
        {
            double cur = _heights[i];
            _heights[i] = target > cur
                ? cur + (target - cur) * RISE_COEFF
                : cur + (target - cur) * FALL_COEFF;

            if (_heights[i] >= _peaks[i]) _peaks[i] = _heights[i];
            else _peaks[i] = Math.Max(0, _peaks[i] - PEAK_FALL_PX);
        }

        private double ComputeTarget(int i, double canvasH, bool hasData)
        {
            var currentFft = _fftData;
            if (!hasData || _binStart == null || currentFft == null || i >= _barCount)
                return 0;

            float maxMag = 0f;
            int end = Math.Min(_binEnd[i], currentFft.Length);
            for (int b = _binStart[i]; b < end; b++)
                if (currentFft[b] > maxMag) maxMag = currentFft[b];

            if (maxMag <= 1e-9f) return 0;

            double eq = i < 5
                ? LOW_EQ_SCALE
                : 1.0 + HIGH_EQ_BOOST * i / _barCount;

            return Math.Min(canvasH, Math.Sqrt(maxMag) * BAR_AMPLITUDE * eq * canvasH);
        }

        private void DrawFrame(double w, double h)
        {
            double slotW   = w / _barCount;
            double barW    = Math.Max(MIN_BAR_PX, Math.Min(MAX_BAR_PX, slotW * BAR_FILL_RATIO));
            double barOffX = (slotW - barW) / 2.0;

            using (DrawingContext dc = _dv.RenderOpen())
            {
                for (int i = 0; i < _barCount; i++)
                {
                    double barH = Math.Max(MIN_BAR_H, _heights[i]);
                    double t    = (double)i / Math.Max(1, _barCount - 1);
                    double x    = i * slotW + barOffX;

                    dc.DrawRoundedRectangle(GetCachedBrush(t), null,
                        new Rect(x, h - barH, barW, barH),
                        BAR_CORNER, BAR_CORNER);

                    if (_peaks[i] > MIN_BAR_H)
                        dc.DrawRectangle(PeakBrush, null,
                            new Rect(x, h - _peaks[i] - PEAK_OFFSET, barW, PEAK_H));
                }
            }
        }

        private void RebuildBinMapping()
        {
            // FIX: Защита от вызова до установки sampleRate
            if (_barCount <= 0 || _sampleRate <= 0) return;

            _binStart = new int[_barCount];
            _binEnd   = new int[_barCount];

            double binHz = (double)_sampleRate / FFT_LENGTH;
            int maxBin   = FFT_LENGTH / 2 - 1;

            for (int i = 0; i < _barCount; i++)
            {
                double lo = MIN_FREQ * Math.Pow(MAX_FREQ / MIN_FREQ, (double)i       / _barCount);
                double hi = MIN_FREQ * Math.Pow(MAX_FREQ / MIN_FREQ, (double)(i + 1) / _barCount);

                _binStart[i] = Math.Max(1, (int)(lo / binHz));
                _binEnd[i]   = Math.Min(maxBin, (int)(hi / binHz) + 1);

                if (_binEnd[i] <= _binStart[i])
                    _binEnd[i] = Math.Min(_binStart[i] + 1, maxBin);
            }
        }

        private static Brush MakeBrush(Color color)
        {
            var b = new SolidColorBrush(color);
            b.Freeze();
            return b;
        }
    }
}
